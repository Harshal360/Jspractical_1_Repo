/*
CODING CHALLANGE 2
*/

var scoreJohn = (123 + 100 + 111) / 3;
var scoreMark = (116 + 94 +103) / 3;
var scoreMary = (97 + 134 + 105 ) /3;
console.log("Avergae of John's Team is : " +scoreJohn);
console.log("Avergae of Mark's Team is : " +scoreMark);
console.log("Avergae of Mark's Team is : " +scoreMary);


if(scoreJohn > scoreMark && scoreJohn > scoreMary){
  console.log("Team John wins!! ");
  console.log("his average score is: "+scoreJohn);
}
else if(scoreMary > scoreMark && scoreMary > scoreJohn){
 console.log("Team Mary wins!");
}
 else if(scoreJohn === scoreMark){
   console.log("match is Draw!");
 }

else{
  console.log("Team Mark Wins!!");
  console.log("his average score is: "+scoreMark);
}

