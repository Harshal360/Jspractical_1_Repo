/*
     Simple(basic concept)



var firstPerson = prompt('Enter Name of First Person');
console.log(firstPerson);

var secondPerson = prompt('Enter Name of second Person');
console.log(secondPerson);

console.log('hello '+ firstPerson +' & '+secondPerson +'.please fill following details... Here');


//  MASS 
var firstMass = prompt(firstPerson + ' !! Enter your Mass please.');
console.log(firstPerson +'!..your Mass is '+ firstMass+' kg');

var secondMass = prompt(secondPerson + ' !! Enter your Mass please.');
console.log(secondPerson+'!..your Mass is '+ secondMass + ' kg');


//Height
var firstHeight = prompt(firstPerson + ' !! Enter your height(in cm) please.');
console.log(firstPerson +'!..your Height is '+ firstHeight+' cm');

var SecondHeight = prompt(secondPerson + ' !! Enter your height(in cm) please.');
console.log(secondPerson +'!..your Height is '+ SecondHeight+' cm');

alert("want to know your BMI, click on OK"); 

var bmiOne = (firstMass) / (firstHeight * firstHeight);
console.log('BMI of  '+firstPerson+ ' is '+bmiOne * 10000);

var bmiTwo =( secondMass) / (SecondHeight * SecondHeight) ;
console.log('BMI of  '+secondPerson+ ' is '+bmiTwo * 10000);

console.log('Is '+firstPerson+'\'s BMI greater than  '+secondPerson+'\'s BMI ?');
var higherBmi = bmiOne > bmiTwo ;

console.log(higherBmi);

*/


/**
 *    using Object and methods 
 * 
 */
var Mark = {
     fullName:'Mark stephen',
     mass:60,
     height:162,
     calBmi:function(mass,height) {
         return this.mass / (this.height * this.height);
     

     }
    
};

  Mark.data = Mark.calBmi() ;
  
  console.log(Mark.data);