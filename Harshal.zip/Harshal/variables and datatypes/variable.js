/*****************************************
 * 
 * *
    1)   lecture about variables and daatypes


var firstName = 'harshal';  //camelCase notation
console.log(firstName);


var lastName = 'Gurav';      //strings
console.log(lastName);

var age = 21;             //number
 

var fullAge = true;         //boolean data type
console.log(fullAge);


var job;
console.log(job);           //undifined(not existence)


job = 'Engineer';
console.log(job);

var $now = 23;   //$ allowed 

// not allowed (var 3nows = 3;) 

*/


/*********************************************** 
2) varibales mutation and coersion 
   
    -> alert method
    -> prompt method
 


//type coersion

var firstName = 'Harshal';
var age = 28;

console.log(firstName + ' ' + age);

var job , isMarried ;

job = 'engineer';
isMarried = false;

console.log(firstName + ' ' + age + 'nows old '+  job +'.is he married? ' +isMarried);


//variable mutation 
age = 'twenty one';     //'age' declared again (dynamic typing)....allowed
job = 'driver';

//alert method(alternative method to console.log)
alert(firstName + ' ' + age + ' nows old '+  job +' .is he married? ' +isMarried);

//prompt method
var lastName = prompt('what is his last name?');

console.log(firstName +' '+lastName);

var carrier = prompt('who is he?');

console.log(carrier);

*/
/****************************************
 * 
 * 
 * 3)Basic operators
 * 
 * 
 *
var now, yearHarshu, yearVaish;
now = 2020;
ageHarshu = 22;
ageVaish = 20;
yearHarshu = now - ageHarshu;    //subtraction
yearVaish = now - ageVaish;

 console.log(yearHarshu);

console.log(now + 2);       //addition
console.log(now * 2);       //multipliaction
console.log(now / 2);       //divison


//logical operators
var harshOlder = ageHarshu > ageVaish;  //grater than
console.log(harshOlder);

//typeof operator
console.log(typeof harshOlder);     //boolean
console.log(typeof ageHarshu);      //number
console.log(typeof 'harshu is greater than Vasih');    //string
var x;
console.log(typeof x);              //undefined


*/

/******************************************
 * 
 * 
 * 4)  operator precedence
 * 
 * 
 *

 var now = 2020;
 var yearHarshu = 1998;
 var yearVaish = 2000;
 var fullAge = 22;


 //multiple opearator 
var isfullAge = now - yearHarshu >= fullAge;
console.log(isfullAge);

//grouping


var ageHarshu = now - yearHarshu;
var ageVaish = now - yearVaish;

var average = (ageHarshu + ageVaish )/2;  
console.log(average);


//multiple assignment 
var x,y;

//assignment operator works from right to left
//following opeartion is valid


x  = y = (3 + 5) * 4 - 6 ;    //8 * 4 - 6 // 26   

console.log(x,y);

// More Operator

x = x + 2;   
console.log(x);

x  += 10;
console.log(x);
x++;
console.log(x);


*/

/*******************************************
 * 
 * 5) Functions {DRY} ---> Don't Repeat Yourself
 * 
 * 
 * 


function calculateAge(birthyear){
    return 2020 - birthyear;
}
 
  var age = calculateAge(1998);
 console.log(age);

function yearUntilRetirement(year, firstname){
    var age = calculateAge(year);
    var retirement = 65 - age;
    console.log(firstname + ' retires in  ' + retirement + ' years');
} 
yearUntilRetirement(1998,'harshal');


 */
/****************************************************************
 * 
 * 6) Functions statements and Declarations 
 * 
 * 

var whatDoYouDO = function(job,  firstName){
    switch(job){
        case 'teacher' : return firstName + ' teaches how to code';

        case 'driver' : return firstName + ' drives car in jalgaon'

        case 'designer' : return firstName + ' designs beautiful cases.';

        default : return firstName + ' does nothing';
    }

    

}

console.log(whatDoYouDO('driver', 'harshal'));


*/

/**********************************************************
 * 
 * 7) Array
 * 
 * 
 *

 var names = ['archit', 'om', 'shreya'];
 var years = new Array(2012, 2002, 2004);

 console.log(names[3]);
 console.log(names.length);

 //mutate array data
 names[1] = 'aaru';
 names[names.length] = 'mary';
 console.log(names);


 //different data types

 var harshal = ['harshal', 'gurav', 1998, 'Engineer'];
 
 harshal.push('blue');                //push
 harshal.unshift('Mr. ');             //unshift
 harshal.pop();                       //pop
 //harshal.pop();                       //pop
 harshal.shift();                     //shift
 console.log(harshal);      


console.log(harshal.indexOf(1998));

var isEngineer = harshal.indexOf('Engineer') === -1 ? 'harshal is not a engineer' : 'harshal is Engineer'; 
 
console.log(isEngineer);

*/
/**
 * 8) object and properties
 * 
 * 
 * 

var harshal = {
    firstName: 'harshal',
    lastName: 'Gurav',
    birthyear: '1998',
    family: ['harshal','vaishanvi','vinay','nilima'],
   // job = 'student',
    isMarried: false
};
  console.log(harshal.family[2]);
  var x = 'birthyear';
  console.log(harshal[x]);

  harshal.job = 'engineer';
  harshal['isMarried'] = true;
  console.log(harshal);

  var jane = new Object();               //New object syntax

  jane.name = 'jane';
  jane.birthyear = 1969;
  console.log(jane);
*/


/**
 * 
 * 9) Objects and methods
 * 
 * 
 */

var harshal = {
    firstName: 'harshal',
    lastName: 'Gurav',
    birthyear: '2000',
    family: ['harshal','vaishanvi','vinay','nilima'],
    job: 'student',
    isMarried: false,

    calcAge: function(birthyear){
             return 2020 - this.birthyear;  //this ---> harshal.birthyear       

    }
};
harshal.age = harshal.calcAge();
console.log(harshal.age);